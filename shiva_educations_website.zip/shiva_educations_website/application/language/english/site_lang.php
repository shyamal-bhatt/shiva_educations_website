<?php
//aplication successfull
$lang['recieved_applicaton'] = 'Your Application has been submitted successfully, We will contact you soon!';

//vendor product preview
$lang['estimated_t_fee'] = 'Estimated Application Fee';
$lang['course_lvl'] = 'Course Level';

//Home controller remove from form/cart
$lang['delete_clg_from_form']='University Deleted from FORM';

//footer
$lang['blog'] = 'Blog';

//Application form checkout
$lang['application'] = 'Your Application';
$lang['apply'] = 'Apply';

//purchase_steps_helper
$lang['step_your_shortlist']='Your Shortlist';
$lang['step_submit_application']='Application';
$lang['step_application_success']='Successfully Submitted';

// for search bar on home page
$lang['lvl_of_course'] ='Course Categorie';
$lang['by_country'] ='Select Country';
$lang['by_subj'] ='Select Subject';

// for slider
$lang['query'] = 'For More Information';

// home page cards button
$lang['apply'] = "Apply";

// for navbar
$lang['online_form'] = 'Form';
$lang['ur_clg_list'] = 'Shortlist';
$lang['about_us'] = 'About Us';

//for blog page
$lang['most_seen_blog'] = 'Top Universities';

//for Query
$lang['no_clg_for_query'] = 'You have not selected any College for Application';

//for shortlist
$lang['shortlist_clg'] = 'Shortlisted Colleges';
$lang['no_clgs_in_list'] = 'No Colleges Shortlisted';
$lang['back_to_home'] = 'Back to Home';
$lang['proceed'] = 'Proceed';
$lang['estimated_fee'] = 'Estimated Fee';

// for shortlist table
$lang['university']='University';
$lang['country']='Country';

//About us
$lang['feedback'] = 'Feedback';
$lang['feel_free_feedback'] = 'Or feel free to Contact us';

$lang['products'] = 'Courses and Universities';
$lang['sort_by'] = 'Sort by';
$lang['new'] = 'New';
$lang['old'] = 'Old';
$lang['store'] = 'Store';
$lang['in_stock'] = 'In Stock';
$lang['out_of_stock'] = 'Out of stock';
$lang['categories'] = 'Course Categories';
$lang['price'] = 'Price';
$lang['old_price'] = 'Before';
$lang['availability'] = 'Quantity';
$lang['search_now'] = 'Search now';
$lang['details'] = 'Preview';
$lang['products_in_your'] = 'products in yours shopp cart';
$lang['total'] = 'Final sum';
$lang['items'] = 'Products';
$lang['view_cart'] = 'Open shopping cart';
$lang['search_by_keyword_title'] = 'Search for word in the title';
$lang['search_by_keyword_body'] = 'Search for word in the description';
$lang['search_for'] = 'Search for';
$lang['search'] = 'Search';
$lang['price_low'] = 'Low price';
$lang['shipping'] = 'Shipping';
$lang['price_high'] = 'High price';
$lang['add_to_cart'] = 'Add to shopping cart';
$lang['del_from_cart'] = 'Remove from shopping cart';
$lang['checkout'] = 'Checkout';
$lang['no_products'] = 'No products';
$lang['more'] = 'More';
$lang['clear_all'] = 'Clear';
$lang['home'] = 'Home';
$lang['contacts'] = 'Contacts';
$lang['cash_on_delivery'] = 'Cash on Delivery';
$lang['first_name'] = 'Name';
$lang['last_name'] = 'Family';
$lang['email_address'] = 'Email address';
$lang['phone'] = 'Mobile Number';
$lang['address'] = 'Address';
$lang['city'] = 'City';
$lang['post_code'] = 'Post code';
$lang['notes'] = 'Remarks';
$lang['requires'] = 'Required field';
$lang['product'] = 'Product';
$lang['title'] = 'Name';
$lang['quantity'] = 'Quantity';
$lang['back_to_shop'] = 'Back to shop';
$lang['custom_order'] = 'Make order';
$lang['c_o_d_order_completed'] = 'Your order has been adopted successfully, we will contact you to confirm it';
$lang['no_products_in_cart'] = 'Still no items in your cart';
$lang['go_back'] = 'Back';
$lang['procurement_desc'] = 'Most sellers';
$lang['procurement_asc'] = 'Low sellers';
$lang['procurement_title'] = 'Sort by sellers';
$lang['price_title'] = 'Sort by price';
$lang['price_from'] = 'Price from';
$lang['price_to'] = 'Price to';
$lang['added_after'] = 'Added after';
$lang['added_before'] = 'Added before';
$lang['quantity_more_than'] = 'Quantity more than';
$lang['type_a_number'] = 'Type number';
$lang['clear_form'] = 'Clear fields';
$lang['clear_the_filter'] = 'Clear filter';
$lang['best_sellers'] = 'Most sallers';
$lang['num_added_to_cart'] = 'Num added to cart';
$lang['added_on'] = 'Added to shop';
$lang['in_category'] = 'In category';
$lang['description'] = 'Description';
$lang['oder_from_category'] = 'Other articles from this Course Level';
$lang['buy_now'] = 'Buy now';
$lang['no_results'] = 'No results';
$lang['blog'] = 'Blog';
$lang['latest_blog'] = 'Latest blog';
$lang['read_mode'] = 'Read more';
$lang['archive'] = 'Archive';
$lang['no_same_category_products'] = 'No other University from this Course Level';
$lang['no_posts'] = 'No published articles';
$lang['go_back'] = 'Go Back';
$lang['no_archives'] = 'No Archives';
$lang['newsletter'] = 'Newsletter';
$lang['subscribe'] = 'Subscribe';
$lang['about_us'] = 'About SE';
$lang['no_categories'] = 'No categories';
$lang['pages'] = 'Pages';
$lang['contact_us'] = 'Contact us';
$lang['contact_us_feel_free'] = 'Feel free to contact us';
$lang['name'] = 'Name';
$lang['subject'] = 'Subject';
$lang['message'] = 'Message';
$lang['send_message'] = 'Send Message';
$lang['our_office'] = 'About Shiva Education';
$lang['email_added'] = 'Your email address is added';
$lang['freeShippingHeader'] = 'Oder';
$lang['freeShipping'] = 'For order more than %price%%currency% the shipping is free';
$lang['promo'] = 'Promo';
$lang['paypal'] = 'PayPal';
$lang['showXsNav'] = 'Show categories';
$lang['hideXsNav'] = 'Hide categories';
$lang['choose_payment'] = 'Choose payment type';
$lang['cancel_payment'] = 'Cacel payment';
$lang['go_to_paypal'] = 'Go to paypal';
$lang['you_choose_paypal'] = 'You choose tha PayPal payment method. To buy your products please continue.';
$lang['paypal_cancel_msg'] = 'You successful cancel paypal order.';
$lang['paypal_success_msg'] = 'You successful buy your order!';
$lang['not_selected'] = 'Not selected';
$lang['shopping_cart'] = 'Shopping Cart';
$lang['deleted_product_from_cart'] = 'The product is deleted from shopping cart';
$lang['final_step'] = 'Save order';
$lang['order_correction'] = 'Order correction';
$lang['you_choose_payment'] = 'You choose payment with:';
$lang['shopping_cart_only'] = 'Shopping Cart';
$lang['your_basket'] = 'Your Basket';
$lang['checkout_top_header'] = 'Checkout';
$lang['step_your_order'] = 'Your order';
$lang['step_payment_method'] = 'Method of payment';
$lang['step_success_prod'] = 'Successful procurement';
$lang['info_product_list'] = 'For More Information';
$lang['empty'] = 'Empty';
$lang['others'] = 'Others';
$lang['welcome'] = 'Online store for clothes';
$lang['social'] = 'Social media';
$lang['no_sub_categories'] = 'No subcategories';
$lang['bank_payment'] = 'Bank payment';
$lang['bank_recipient_name'] = 'Pay - The name of the recipient';
$lang['bank_iban'] = 'IBAN of the beneficiary';
$lang['bank_bic'] = 'BIC of recipient';
$lang['bank_name'] = 'in Bank';
$lang['bank_reason'] = 'Reason for payment';
$lang['the_reason'] = 'Payment of order with number';
$lang['brands'] = 'Brands';
$lang['first_name_empty'] = 'You have not entered name';
$lang['last_name_empty'] = 'You have not entered family';
$lang['invalid_email'] = 'Invalid email address';
$lang['invalid_phone'] = 'Invalid phone';
$lang['address_empty'] = 'You have not entered address';
$lang['invalid_city'] = 'You have not entered city';
$lang['invalid_post_code'] = 'You have not entered post code';
$lang['finded_errors'] = 'Following errors in credentials';
$lang['out_of_stock_product'] = 'Product is out of stock';
$lang['there_is_payment_error'] = 'There are problem with order. Please contact us by phone!';
$lang['confirm_order_subj'] = 'Confirm order from - ';
$lang['please_confirm'] = 'Please confirm your order when click on - ';
$lang['order_confirmed'] = 'Your order is confirmed!';
$lang['discount_code'] = 'Discount code';
$lang['check_code'] = 'Check code';
$lang['enter_discount_code'] = 'Enter code here';
$lang['final_amount_for_pay'] = 'Payment amount';
$lang['database_error'] = 'A problem occured! Please contact support!';
$lang['email'] = 'Email';
$lang['password'] = 'Password';
$lang['remember_me'] = 'Remember me';
$lang['u_login'] = 'Login';
$lang['register_me'] = 'Register';
$lang['user_login_page'] = 'User login';
$lang['open_your_account'] = 'Add your products and sell directly through us';
$lang['login_to_your_acc'] = 'Login to Your Account';
$lang['forgot_pass'] = 'Forgot Password';
$lang['user_register_page'] = 'Register new user';
$lang['create_account'] = 'Create a sales account';
$lang['user_forgotten_page'] = 'Password Recovery';
$lang['recover_password'] = 'Restore your password';
$lang['password_repeat'] = 'Repeat password';
$lang['send_me_new_pass'] = 'Send me new password';
$lang['passwords_dont_match'] = 'Passwords dont match';
$lang['vendor_invalid_email'] = 'Invalid email address';
$lang['please_enter_password'] = 'Please enter a password';
$lang['please_repeat_password'] = 'Please repeat the password';
$lang['vendor_email_is_taken'] = 'Email address already registered';
$lang['login_vendor_error'] = 'Wrong email or password';
$lang['vendor_add_product'] = 'Add product';
$lang['vendor_dashboard'] = 'Dashboard';
$lang['vendor_products'] = 'Products';
$lang['vendor_home'] = 'Home';
$lang['vendor_logout'] = 'Logout';
$lang['vendor_product_name'] = 'Product name';
$lang['vendor_product_description'] = 'Product description';
$lang['vendor_cover_image'] = 'Cover image';
$lang['vendor_current_image'] = 'Current image';
$lang['vendor_up_more_imgs'] = 'Upload more images';
$lang['finish'] = 'Finish';
$lang['vendor_select_images'] = 'Select images';
$lang['vendor_select_category'] = 'Choose category';
$lang['vendor_price'] = 'Price';
$lang['vendor_old_price'] = 'Old price';
$lang['vendor_quantity'] = 'Quantity';
$lang['vendor_position'] = 'Position';
$lang['vendor_orders'] = 'Orders';
$lang['vendor_submit_product'] = 'Upload product';
$lang['vendor_product_published'] = 'Product is published';
$lang['vendor_product_publish_err'] = 'Problem with product publish';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';
$lang['vendor_sure_to_del_product'] = 'Are you sure you want to delete this product?';
$lang['vendor_product_deleted'] = 'Product deleted';
$lang['vendor_view'] = 'Vendor view ';
$lang['vendor'] = 'Vendor';
$lang['vendor_name'] = 'Vendor name';
$lang['vendor_url'] = 'Address [a-zA-Z0-9]';
$lang['enter_vendor_name'] = 'Enter a sellers name';
$lang['enter_vendor_url'] = 'Enter the sellers address';
$lang['vendor_details_updated'] = 'Vendor information has been updated';
$lang['vendor_url_taken'] = 'The address is busy';
$lang['time_created'] = 'Date of creation';
$lang['order_type'] = 'Order type';
$lang['status'] = 'Status';
$lang['processed'] = 'Processed';
$lang['rejected'] = 'Rejected';
$lang['call_us'] = 'Order online or call us:';
$lang['search_here'] = 'Search here...';
$lang['new_products'] = 'New Products';
$lang['blog_posts'] = 'Blog posts';
$lang['read_more'] = 'read more';
$lang['menu'] = 'Menu';
$lang['go_to_checkout'] = 'Go to checkout';
$lang['shop'] = 'Shop';
$lang['billing_details'] = 'Billing Details';
$lang['your_order'] = 'Your order';
$lang['contact_details'] = 'Contact detail';
$lang['user_login'] = 'User login';
$lang['login_to_acc'] = 'Login to your account';
$lang['login'] = 'Login';
$lang['register'] = 'Register';
$lang['forgot_pass'] = 'Forgot password';
$lang['wrong_user'] ='Wrong username or password!';
$lang['user_register'] = 'User registration';
$lang['please_enter_name'] = 'Please enter name';
$lang['please_enter_phone']  = 'Please enter phone';
$lang['enter_password'] ='Please enter password';
$lang['pass_repeat'] ='Please repeat password';
$lang['user_email_is_taken'] = 'Email address is taken!';
$lang['my_acc']  ='My Profile'; 
$lang['update']  = 'Update';
$lang['logout'] = 'Logout';
$lang['price_qua']  = 'Price for quantity';
$lang['total_prod']  = 'Total';
$lang['my_order'] = 'My order';
$lang['new_pass_sended'] = 'New password sended';
$lang['usr_order_id'] = 'Order id';
$lang['usr_order_date'] = 'Date';
$lang['usr_order_address'] = 'Address';
$lang['usr_order_phone'] = 'Phone';
$lang['user_order_products'] = 'Products';
$lang['user_order_quantity'] = 'Quantity:';
$lang['usr_no_orders'] = 'No purchases made';