<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-03 06:53:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 13:38:53 --> 404 Page Not Found: /index
ERROR - 2022-02-03 13:38:53 --> 404 Page Not Found: /index
ERROR - 2022-02-03 14:09:33 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-03 14:09:43 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 14:18:47 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-03 14:47:12 --> 404 Page Not Found: /index
ERROR - 2022-02-03 14:47:12 --> 404 Page Not Found: /index
ERROR - 2022-02-03 15:45:53 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 15:48:48 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-03 15:56:46 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 77
ERROR - 2022-02-03 15:56:53 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 77
ERROR - 2022-02-03 15:56:57 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 77
ERROR - 2022-02-03 15:57:02 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 77
ERROR - 2022-02-03 15:57:06 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 77
ERROR - 2022-02-03 15:57:09 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 77
ERROR - 2022-02-03 16:03:44 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-03 16:03:54 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-03 16:06:16 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:06:21 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:06:48 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:10:19 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:11:15 --> 404 Page Not Found: /index
ERROR - 2022-02-03 16:11:15 --> 404 Page Not Found: /index
ERROR - 2022-02-03 16:11:15 --> 404 Page Not Found: /index
ERROR - 2022-02-03 16:13:48 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:13:48 --> 404 Page Not Found: /index
ERROR - 2022-02-03 16:13:48 --> 404 Page Not Found: /index
ERROR - 2022-02-03 16:13:48 --> 404 Page Not Found: /index
ERROR - 2022-02-03 16:19:53 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:19:53 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:19:53 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:19:56 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:19:56 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:19:56 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:19:56 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:20:01 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:20:39 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:20:39 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:20:39 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:21:44 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:21:44 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:21:44 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:21:44 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:21:47 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:21:49 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:21:49 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:21:49 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:21:49 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:21:58 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:22:03 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:22:03 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:22:03 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:22:03 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:22:06 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:22:06 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:23:32 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:23:37 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:28:42 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:29:20 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:29:20 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:29:20 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:29:20 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:29:46 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:29:50 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:29:50 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:29:50 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:29:50 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:29:51 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:31:06 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:31:17 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:31:19 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:31:21 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:32:18 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:33:29 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:34:54 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:35:11 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:36:36 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:36:46 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:36:48 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:36:48 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:36:48 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:36:48 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:36:50 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:37:06 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:37:10 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:37:15 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:37:20 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:37:31 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:37:31 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:37:31 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:37:31 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:37:51 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:37:51 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:37:51 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:38:44 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:38:44 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:38:44 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:38:45 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:38:45 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:38:45 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:38:48 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-03 16:38:48 --> Could not find the language line "your_query"
ERROR - 2022-02-03 16:38:48 --> Could not find the language line "your_query"
