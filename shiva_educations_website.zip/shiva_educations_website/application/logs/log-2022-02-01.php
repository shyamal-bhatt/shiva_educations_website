<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-01 10:08:48 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-01 10:10:17 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-01 10:11:50 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-01 10:14:18 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-01 10:15:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-01 10:16:58 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:16:58 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:16:58 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:21:38 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:21:38 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:21:38 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:47:37 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:47:37 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:47:37 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:40:00 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:40:00 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:40:00 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:42:08 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\home.php 3
ERROR - 2022-02-01 11:42:08 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:42:08 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:42:08 --> 404 Page Not Found: /index
