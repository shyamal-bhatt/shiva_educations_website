<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-08 12:14:31 --> 404 Page Not Found: /index
ERROR - 2022-03-08 12:14:31 --> 404 Page Not Found: /index
ERROR - 2022-03-08 12:14:31 --> 404 Page Not Found: /index
ERROR - 2022-03-08 12:15:19 --> 404 Page Not Found: /index
ERROR - 2022-03-08 12:15:19 --> 404 Page Not Found: /index
ERROR - 2022-03-08 12:15:19 --> 404 Page Not Found: /index
ERROR - 2022-03-08 12:16:36 --> 404 Page Not Found: /index
ERROR - 2022-03-08 12:16:36 --> 404 Page Not Found: /index
ERROR - 2022-03-08 12:16:36 --> 404 Page Not Found: /index
ERROR - 2022-03-08 12:16:43 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-08 13:41:50 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
