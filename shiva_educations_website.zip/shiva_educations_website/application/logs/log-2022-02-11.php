<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-11 10:29:14 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-11 10:29:57 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:29:57 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:29:57 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:30:31 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:30:31 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:30:52 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:30:52 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:30:52 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:30:57 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:30:57 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:30:57 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-11 10:30:57 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:31:07 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:31:07 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:33:39 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:33:39 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:33:39 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:33:45 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:33:45 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:33:45 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-11 10:33:45 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:34:00 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:34:00 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:34:00 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:37:16 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:37:16 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:37:58 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:37:58 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:37:58 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:38:04 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:38:04 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:38:04 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:38:04 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:38:04 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-11 10:38:04 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:38:39 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:38:39 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:38:39 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:38:39 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:38:39 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-11 10:38:39 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:39:39 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:39:39 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:39:45 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:39:45 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:39:45 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:39:48 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:39:48 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:39:48 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-11 10:39:48 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:40:02 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:40:02 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:41:34 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:41:34 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:41:34 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:41:42 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:41:42 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:41:42 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:41:42 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:41:42 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-11 10:41:42 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:41:53 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:41:53 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-11 10:41:53 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-11 10:42:05 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-11 10:42:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
