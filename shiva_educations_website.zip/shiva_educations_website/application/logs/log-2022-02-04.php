<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-04 07:09:15 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:09:15 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:10:07 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:10:07 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:15:34 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:15:34 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:15:43 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 07:15:43 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:15:43 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:15:46 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 07:15:46 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:15:46 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:15:56 --> Severity: Notice --> Undefined index: enteredCode D:\xampp\htdocs\ShivaEducation\application\controllers\Home.php 172
ERROR - 2022-02-04 07:17:02 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:17:02 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:17:09 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:17:09 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:17:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 07:17:12 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:17:12 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:17:17 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 07:17:17 --> Could not find the language line "your_query"
ERROR - 2022-02-04 07:17:17 --> Could not find the language line "your_query"
ERROR - 2022-02-04 08:01:30 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-04 08:03:37 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-04 08:04:05 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 08:04:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 08:04:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 08:04:05 --> Could not find the language line "your_query"
ERROR - 2022-02-04 08:04:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 08:04:05 --> Could not find the language line "your_query"
ERROR - 2022-02-04 08:04:29 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 08:04:29 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 08:04:29 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 08:04:29 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 08:04:29 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 08:04:29 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 08:04:29 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 08:04:29 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 08:04:29 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 08:04:29 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 08:04:29 --> Could not find the language line "your_query"
ERROR - 2022-02-04 08:04:29 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 08:04:29 --> Could not find the language line "your_query"
ERROR - 2022-02-04 08:05:35 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 08:05:35 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 08:05:35 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 08:05:35 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 08:13:12 --> 404 Page Not Found: /index
ERROR - 2022-02-04 08:13:12 --> 404 Page Not Found: /index
ERROR - 2022-02-04 08:13:13 --> 404 Page Not Found: /index
ERROR - 2022-02-04 08:13:40 --> 404 Page Not Found: /index
ERROR - 2022-02-04 08:13:40 --> 404 Page Not Found: /index
ERROR - 2022-02-04 08:13:40 --> 404 Page Not Found: /index
ERROR - 2022-02-04 08:18:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-02-04 08:18:05 --> Unable to connect to the database
ERROR - 2022-02-04 08:18:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-02-04 08:18:07 --> Unable to connect to the database
ERROR - 2022-02-04 08:18:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-02-04 08:18:18 --> Unable to connect to the database
ERROR - 2022-02-04 08:26:59 --> 404 Page Not Found: /index
ERROR - 2022-02-04 09:31:42 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:31:42 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:31:42 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:31:42 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:33:08 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:33:08 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:33:08 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:33:08 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:43:35 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:43:35 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:43:35 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:43:35 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:47:05 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:47:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:47:05 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:47:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:49:50 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:49:50 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:49:50 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:49:50 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:50:46 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-04 09:50:49 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:50:49 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:50:49 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:50:49 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:50:49 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 09:50:49 --> Could not find the language line "your_query"
ERROR - 2022-02-04 09:51:09 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:51:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:51:09 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:51:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:51:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 09:51:09 --> Could not find the language line "your_query"
ERROR - 2022-02-04 09:51:09 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 09:51:09 --> Could not find the language line "your_query"
ERROR - 2022-02-04 09:51:31 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:51:31 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:51:31 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:51:31 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:51:31 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 09:51:31 --> Could not find the language line "your_query"
ERROR - 2022-02-04 09:54:14 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:54:14 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:54:14 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 80
ERROR - 2022-02-04 09:54:14 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 83
ERROR - 2022-02-04 09:54:14 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 09:54:14 --> Could not find the language line "your_query"
ERROR - 2022-02-04 09:59:43 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 81
ERROR - 2022-02-04 09:59:43 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 84
ERROR - 2022-02-04 09:59:43 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 81
ERROR - 2022-02-04 09:59:43 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 84
ERROR - 2022-02-04 09:59:43 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 09:59:43 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:10:17 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 81
ERROR - 2022-02-04 10:10:17 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 85
ERROR - 2022-02-04 10:10:17 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 81
ERROR - 2022-02-04 10:10:17 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 85
ERROR - 2022-02-04 10:10:17 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 10:10:17 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:11:55 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 81
ERROR - 2022-02-04 10:11:55 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 81
ERROR - 2022-02-04 10:11:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 10:11:55 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:12:07 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 81
ERROR - 2022-02-04 10:12:07 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 81
ERROR - 2022-02-04 10:12:07 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-04 10:12:07 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:13:50 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-04 10:14:03 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-04 10:14:36 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:14:50 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:14:50 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:14:52 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 10:14:52 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:14:52 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:14:58 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:19:42 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 75
ERROR - 2022-02-04 10:19:42 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:20:22 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:21:44 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:21:57 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:22:47 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:23:32 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:23:47 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:25:52 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:27:11 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:29:37 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:31:08 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:31:40 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:31:40 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:31:40 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:33:52 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:34:28 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:48:29 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:50:19 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:51:08 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:51:23 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:51:34 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:51:43 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:53:05 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:55:07 --> Severity: Notice --> Undefined index: sum_price D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 102
ERROR - 2022-02-04 10:55:07 --> Severity: Notice --> Undefined index: sum_price D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 102
ERROR - 2022-02-04 10:55:07 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:57:07 --> Severity: Notice --> Undefined index: sum_price D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 102
ERROR - 2022-02-04 10:57:07 --> Severity: Notice --> Undefined index: sum_price D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 102
ERROR - 2022-02-04 10:57:07 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:57:30 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:57:45 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:57:55 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:58:37 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:59:02 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:59:40 --> Could not find the language line "your_query"
ERROR - 2022-02-04 10:59:47 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:02:22 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:03:17 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:05:20 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:05:28 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:07:22 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:08:12 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:08:48 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:09:44 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:10:23 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:11:24 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:12:30 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 121
ERROR - 2022-02-04 11:12:30 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:12:43 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:13:48 --> Could not find the language line "your_query"
ERROR - 2022-02-04 11:19:44 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:19:44 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:19:44 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:34:46 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:34:46 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:34:46 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:39:40 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:39:40 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:39:40 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:39:49 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 11:39:53 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 11:40:01 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 11:53:10 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 12:18:23 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 12:24:44 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-04 12:26:30 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:26:30 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:26:30 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:27:35 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 13
ERROR - 2022-02-04 12:30:42 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:30:42 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:30:42 --> 404 Page Not Found: /index
