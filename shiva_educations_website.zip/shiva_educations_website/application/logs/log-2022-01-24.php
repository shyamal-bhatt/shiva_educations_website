<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-24 15:29:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\Ecommerce\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-01-24 15:29:36 --> Unable to connect to the database
ERROR - 2022-01-24 15:36:09 --> 404 Page Not Found: /index
ERROR - 2022-01-24 15:36:20 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang D:\xampp\htdocs\Ecommerce\application\modules\admin\models\Blog_model.php 34
ERROR - 2022-01-24 15:36:20 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang D:\xampp\htdocs\Ecommerce\application\modules\admin\models\Blog_model.php 0
ERROR - 2022-01-24 15:36:20 --> 404 Page Not Found: /index
ERROR - 2022-01-24 15:36:42 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang D:\xampp\htdocs\Ecommerce\application\modules\admin\models\Blog_model.php 34
ERROR - 2022-01-24 15:36:42 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang D:\xampp\htdocs\Ecommerce\application\modules\admin\models\Blog_model.php 0
ERROR - 2022-01-24 15:36:42 --> 404 Page Not Found: /index
ERROR - 2022-01-24 15:37:13 --> 404 Page Not Found: /index
ERROR - 2022-01-24 15:37:29 --> 404 Page Not Found: /index
ERROR - 2022-01-24 15:37:30 --> 404 Page Not Found: /index
ERROR - 2022-01-24 15:37:35 --> 404 Page Not Found: /index
ERROR - 2022-01-24 15:38:03 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang D:\xampp\htdocs\Ecommerce\application\modules\admin\models\Blog_model.php 34
ERROR - 2022-01-24 15:38:03 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang D:\xampp\htdocs\Ecommerce\application\modules\admin\models\Blog_model.php 0
ERROR - 2022-01-24 16:46:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'shop' D:\xampp\htdocs\Ecommerce\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-01-24 16:46:20 --> Unable to connect to the database
ERROR - 2022-01-24 16:47:29 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:47:31 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:47:34 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:47:34 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:47:35 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:47:36 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:48:12 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:48:28 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:48:32 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:48:39 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:48:41 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:48:42 --> 404 Page Not Found: /index
ERROR - 2022-01-24 16:48:44 --> 404 Page Not Found: /index
