<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-13 07:52:39 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 07:55:09 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:55:09 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:55:09 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:32 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:32 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:32 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:33 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:33 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:33 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 07:56:33 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:33 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:34 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:36 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:36 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:36 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:36 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 07:56:37 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:37 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:56:37 --> 404 Page Not Found: /index
ERROR - 2022-02-13 07:58:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 07:58:16 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 08:01:06 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 08:20:29 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 08:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 08:24:20 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 08:26:01 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:26:01 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:26:01 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:28:13 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:28:14 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:28:14 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:38:14 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:38:14 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:38:14 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:20 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:20 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:20 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:27 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:27 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:27 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:47 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:47 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:47 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:49 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:49 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:49 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:56 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:56 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:39:57 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:40:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:40:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:40:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:40:36 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:40:36 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:40:37 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:44:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:44:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:44:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:45:23 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:45:23 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:45:23 --> 404 Page Not Found: /index
ERROR - 2022-02-13 08:55:10 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 08:55:49 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 09:00:38 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-13 09:03:21 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 09:03:26 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 11:14:26 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\ShivaEducation\system\libraries\Email.php 1902
ERROR - 2022-02-13 11:17:09 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 11:32:51 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:32:51 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:32:51 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:32:56 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:32:56 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:32:56 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:50:57 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:50:57 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:50:57 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:14 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:14 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:14 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:42 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:42 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:51:42 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:52:02 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:52:02 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:52:02 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:52:15 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:52:15 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:52:15 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:58:21 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 16
ERROR - 2022-02-13 11:58:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 18
ERROR - 2022-02-13 11:58:21 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 18
ERROR - 2022-02-13 11:58:21 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 16
ERROR - 2022-02-13 11:58:21 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 18
ERROR - 2022-02-13 11:58:21 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 18
ERROR - 2022-02-13 11:58:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:58:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 11:58:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:00:21 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 16
ERROR - 2022-02-13 12:00:21 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 17
ERROR - 2022-02-13 12:00:21 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 17
ERROR - 2022-02-13 12:00:21 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 16
ERROR - 2022-02-13 12:00:21 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 17
ERROR - 2022-02-13 12:00:21 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 17
ERROR - 2022-02-13 12:00:21 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:00:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:00:22 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:01:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 16
ERROR - 2022-02-13 12:01:07 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 16
ERROR - 2022-02-13 12:01:07 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 17
ERROR - 2022-02-13 12:01:07 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 17
ERROR - 2022-02-13 12:01:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 16
ERROR - 2022-02-13 12:01:07 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 16
ERROR - 2022-02-13 12:01:07 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 17
ERROR - 2022-02-13 12:01:07 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 17
ERROR - 2022-02-13 12:01:08 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:01:08 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:01:08 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:01:42 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:01:42 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:01:42 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:02:17 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:02:17 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:02:17 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:02:31 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:02:31 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:02:31 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:03:32 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:03:32 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:03:32 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:04:13 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:04:13 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:04:13 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:04:34 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:04:34 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:04:34 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:04:45 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 13
ERROR - 2022-02-13 12:04:45 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 15
ERROR - 2022-02-13 12:04:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 15
ERROR - 2022-02-13 12:04:45 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 20
ERROR - 2022-02-13 12:05:01 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 12:07:11 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 13
ERROR - 2022-02-13 12:07:11 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 15
ERROR - 2022-02-13 12:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 15
ERROR - 2022-02-13 12:07:11 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 21
ERROR - 2022-02-13 12:11:09 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:11:09 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:11:09 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:20:34 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 12:20:43 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 12:20:53 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 12:21:12 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-02-13 12:27:29 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 12:27:38 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-02-13 12:44:19 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:44:19 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:44:19 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:48:51 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:48:51 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:48:51 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:50:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:50:35 --> 404 Page Not Found: /index
ERROR - 2022-02-13 12:50:36 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:04:24 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\ShivaEducation\system\libraries\Email.php 1902
ERROR - 2022-02-13 13:04:53 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\ShivaEducation\system\libraries\Email.php 1902
ERROR - 2022-02-13 13:16:31 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\ShivaEducation\system\libraries\Email.php 1902
ERROR - 2022-02-13 13:16:33 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\ShivaEducation\system\libraries\Email.php 1902
ERROR - 2022-02-13 13:22:07 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\ShivaEducation\system\libraries\Email.php 1902
ERROR - 2022-02-13 13:39:11 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:39:11 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:39:11 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:47:13 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:47:13 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:47:13 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:48:20 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:48:20 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:12 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:13 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:13 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:21 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:21 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:21 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:29 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:29 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:29 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:44 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:44 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:52:44 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:53:02 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:53:02 --> 404 Page Not Found: /index
ERROR - 2022-02-13 13:53:02 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:01 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:02 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:02 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:06 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:06 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:06 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:16 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:17 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:17 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:21 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:21 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:21 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:23 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:23 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:23 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:26 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:26 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:26 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:56 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:57 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:57 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:28:59 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:29:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:29:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:29:46 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:29:46 --> 404 Page Not Found: /index
ERROR - 2022-02-13 14:29:46 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:15:09 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:15:09 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:15:09 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:21:11 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:21:11 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:21:11 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:22:47 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:22:47 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:22:47 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:23:00 --> Severity: Notice --> Undefined index: settings D:\xampp\htdocs\ShivaEducation\application\modules\admin\views\ecommerce\orders.php 5
ERROR - 2022-02-13 16:23:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:23:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:23:00 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:23:37 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:23:37 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:23:37 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:27:51 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:27:51 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:28:06 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:28:06 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:28:43 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:28:43 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:28:58 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:28:59 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:38:05 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-13 16:38:17 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-02-13 16:38:45 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:38:45 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:38:45 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:43:32 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:43:32 --> 404 Page Not Found: /index
ERROR - 2022-02-13 16:43:32 --> 404 Page Not Found: /index
