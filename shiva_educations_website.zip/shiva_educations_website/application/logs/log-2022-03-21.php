<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-21 05:32:48 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-21 08:12:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-03-21 08:12:02 --> Unable to connect to the database
ERROR - 2022-03-21 08:16:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-03-21 08:16:19 --> Unable to connect to the database
ERROR - 2022-03-21 13:50:42 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
