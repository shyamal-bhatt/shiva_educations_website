<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-26 11:53:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 11:54:19 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 11:55:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:55:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:55:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:06:17 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:06:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:06:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:06:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:07:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:07:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:07:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:12:30 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:12:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:12:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:12:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:12:42 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:12:47 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:13:00 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:13:07 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:13:09 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:13:22 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:14:28 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:14:45 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:25:52 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:29:50 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:32:37 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:32:50 --> 404 Page Not Found: Checkout/index
ERROR - 2022-03-26 12:34:07 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:34:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:34:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:34:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:38:35 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:38:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:38:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:38:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:39:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:39:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:39:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:42:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:42:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:42:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:42:11 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:42:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:42:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:42:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:43:11 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-26 12:43:22 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
