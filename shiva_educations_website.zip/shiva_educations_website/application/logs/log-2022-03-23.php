<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-23 12:59:58 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-23 13:00:47 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-23 13:01:02 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-23 13:02:03 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-23 13:02:06 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-23 13:22:52 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-23 13:23:23 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-03-23 13:28:22 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-23 13:28:58 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-03-23 13:29:29 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-23 13:29:48 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-03-23 13:33:00 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\ShivaEducation\system\libraries\Email.php 1902
ERROR - 2022-03-23 13:33:44 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\ShivaEducation\system\libraries\Email.php 1902
