<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-28 12:59:30 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
