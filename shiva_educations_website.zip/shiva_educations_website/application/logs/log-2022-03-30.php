<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-30 04:20:35 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-03-30 04:22:57 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-03-30 04:36:16 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-03-30 06:42:58 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\controllers\Home.php 130
ERROR - 2022-03-30 06:42:58 --> 404 Page Not Found: 
ERROR - 2022-03-30 06:43:13 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\controllers\Home.php 130
ERROR - 2022-03-30 06:43:13 --> 404 Page Not Found: 
ERROR - 2022-03-30 06:43:23 --> 404 Page Not Found: Blog/localhost
ERROR - 2022-03-30 06:44:59 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-03-30 07:00:37 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-30 07:01:05 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-30 07:25:16 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-30 07:25:50 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
