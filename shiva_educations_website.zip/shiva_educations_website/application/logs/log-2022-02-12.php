<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-12 04:28:33 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-12 04:28:33 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-12 04:28:33 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-12 04:30:39 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-12 04:30:39 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-12 04:30:39 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\Loop.php 131
ERROR - 2022-02-12 04:35:54 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 105
ERROR - 2022-02-12 04:35:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given D:\xampp\htdocs\ShivaEducation\application\libraries\ShoppingCart.php 118
ERROR - 2022-02-12 04:36:33 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-12 04:41:13 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:41:13 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:41:13 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:48:09 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:48:09 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:48:09 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:48:40 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-12 04:50:56 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:50:56 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:50:56 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:51:52 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:51:52 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:51:52 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:51:55 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:51:55 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:51:55 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:54:04 --> Severity: error --> Exception: syntax error, unexpected '$lang' (T_VARIABLE) D:\xampp\htdocs\ShivaEducation\application\language\english\site_lang.php 36
ERROR - 2022-02-12 04:56:26 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:56:26 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:56:26 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:59:20 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:59:20 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:59:20 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:59:43 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:59:43 --> 404 Page Not Found: /index
ERROR - 2022-02-12 04:59:43 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:00:07 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:00:07 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:00:07 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:02:15 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:02:15 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:02:15 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:02:50 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:02:50 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:02:50 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:05:10 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-12 05:05:24 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 13
ERROR - 2022-02-12 05:05:46 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 13
ERROR - 2022-02-12 05:07:18 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-12 05:07:51 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-12 05:08:03 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-02-12 05:08:35 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:08:35 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:08:35 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:09:52 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 48
ERROR - 2022-02-12 05:09:53 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:09:53 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:09:53 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:10:27 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 49
ERROR - 2022-02-12 05:10:28 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:10:28 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:10:28 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:12:24 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 51
ERROR - 2022-02-12 05:12:25 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:12:25 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:12:25 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:12:33 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 51
ERROR - 2022-02-12 05:12:33 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:12:33 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:12:33 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:14:26 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:14:26 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:14:26 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:14:26 --> 404 Page Not Found: /index
ERROR - 2022-02-12 05:16:24 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:20:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:21:07 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:21:38 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:22:16 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:23:15 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:24:18 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:24:19 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:24:58 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:24:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:25:21 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:25:22 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:25:35 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 05:25:48 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:00:15 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:00:24 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:00:24 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:00:24 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:01:04 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:01:04 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:01:05 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:01:05 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:03:00 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:03:30 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:04:00 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:04:05 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:04:26 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:04:26 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:04:26 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:06:50 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:06:55 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:09:52 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:09:52 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:09:52 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:09:58 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:09:58 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:09:58 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:09:58 --> 404 Page Not Found: /index
ERROR - 2022-02-12 06:11:02 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 13
ERROR - 2022-02-12 06:11:21 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:11:58 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:12:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:25:50 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 06:26:00 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:10:09 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:10:11 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:12:45 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 13
ERROR - 2022-02-12 08:36:43 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 13
ERROR - 2022-02-12 08:36:51 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:45:02 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:45:25 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:45:38 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:45:41 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:47:24 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:52:25 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:53:19 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:53:33 --> 404 Page Not Found: /index
ERROR - 2022-02-12 08:53:33 --> 404 Page Not Found: /index
ERROR - 2022-02-12 08:53:33 --> 404 Page Not Found: /index
ERROR - 2022-02-12 08:53:36 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:53:37 --> 404 Page Not Found: /index
ERROR - 2022-02-12 08:53:37 --> 404 Page Not Found: /index
ERROR - 2022-02-12 08:53:37 --> 404 Page Not Found: /index
ERROR - 2022-02-12 08:54:51 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:58:28 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 08:58:38 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-02-12 09:03:30 --> Severity: Notice --> Trying to access array offset on value of type int D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\shopping_cart.php 13
ERROR - 2022-02-12 09:03:38 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:03:41 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:04:31 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:05:00 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-02-12 09:11:45 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-12 09:11:53 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-02-12 09:13:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:15:29 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:16:09 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:17:03 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:18:40 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:19:03 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:20:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:20:46 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:20:52 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:20:52 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:20:52 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:21:46 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:21:47 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:21:47 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:21:47 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:24:17 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:24:18 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:24:18 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:24:18 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:25:59 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-12 09:26:00 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:26:00 --> 404 Page Not Found: /index
ERROR - 2022-02-12 09:26:00 --> 404 Page Not Found: /index
