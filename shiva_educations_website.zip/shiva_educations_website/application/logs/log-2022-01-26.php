<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-26 04:58:27 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\ShivaEducation\system\libraries\Email.php 1902
ERROR - 2022-01-26 04:58:35 --> 404 Page Not Found: /index
ERROR - 2022-01-26 04:58:35 --> 404 Page Not Found: /index
ERROR - 2022-01-26 04:58:35 --> 404 Page Not Found: /index
ERROR - 2022-01-26 05:02:03 --> 404 Page Not Found: /index
ERROR - 2022-01-26 05:02:04 --> 404 Page Not Found: /index
ERROR - 2022-01-26 05:02:04 --> 404 Page Not Found: /index
ERROR - 2022-01-26 05:24:36 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\ShivaEducation\system\libraries\Email.php 1902
ERROR - 2022-01-26 05:28:05 --> Severity: Notice --> Undefined variable: arr D:\xampp\htdocs\ShivaEducation\application\models\Public_model.php 523
ERROR - 2022-01-26 05:28:05 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\models\Public_model.php 523
ERROR - 2022-01-26 06:14:29 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:14:29 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:14:30 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:19:06 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:19:06 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:19:06 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:19:42 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:19:42 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:19:43 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:22:43 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:22:43 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:22:43 --> 404 Page Not Found: /index
ERROR - 2022-01-26 06:23:33 --> 404 Page Not Found: 
ERROR - 2022-01-26 07:53:54 --> 404 Page Not Found: /index
ERROR - 2022-01-26 07:53:54 --> 404 Page Not Found: /index
ERROR - 2022-01-26 07:53:54 --> 404 Page Not Found: /index
ERROR - 2022-01-26 08:21:42 --> 404 Page Not Found: /index
ERROR - 2022-01-26 08:21:42 --> 404 Page Not Found: /index
ERROR - 2022-01-26 08:21:42 --> 404 Page Not Found: /index
ERROR - 2022-01-26 08:50:03 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-01-26 08:52:55 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-01-26 08:53:42 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-01-26 09:03:44 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 80
ERROR - 2022-01-26 10:05:49 --> 404 Page Not Found: /index
ERROR - 2022-01-26 10:05:49 --> 404 Page Not Found: /index
ERROR - 2022-01-26 10:05:49 --> 404 Page Not Found: /index
