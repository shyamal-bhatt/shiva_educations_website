<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-05 10:41:12 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-04-05 10:41:18 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-04-05 10:42:13 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-04-05 10:46:19 --> 404 Page Not Found: 
ERROR - 2022-04-05 10:46:37 --> 404 Page Not Found: 
