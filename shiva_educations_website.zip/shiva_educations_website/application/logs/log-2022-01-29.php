<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-29 04:39:26 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-01-29 04:39:55 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-01-29 04:46:59 --> 404 Page Not Found: /index
ERROR - 2022-01-29 04:46:59 --> 404 Page Not Found: /index
ERROR - 2022-01-29 04:51:34 --> 404 Page Not Found: /index
ERROR - 2022-01-29 04:51:35 --> 404 Page Not Found: /index
ERROR - 2022-01-29 04:55:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-01-29 04:55:28 --> Unable to connect to the database
ERROR - 2022-01-29 04:55:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-01-29 04:55:44 --> Unable to connect to the database
ERROR - 2022-01-29 04:56:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-01-29 04:56:29 --> Unable to connect to the database
ERROR - 2022-01-29 04:56:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-01-29 04:56:47 --> Unable to connect to the database
ERROR - 2022-01-29 04:56:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-01-29 04:56:54 --> Unable to connect to the database
ERROR - 2022-01-29 04:57:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\ShivaEducation\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-01-29 04:57:27 --> Unable to connect to the database
ERROR - 2022-01-29 05:14:03 --> 404 Page Not Found: /index
ERROR - 2022-01-29 05:14:03 --> 404 Page Not Found: /index
ERROR - 2022-01-29 05:14:03 --> 404 Page Not Found: /index
ERROR - 2022-01-29 05:14:03 --> 404 Page Not Found: /index
ERROR - 2022-01-29 05:14:03 --> 404 Page Not Found: /index
ERROR - 2022-01-29 05:14:04 --> 404 Page Not Found: /index
ERROR - 2022-01-29 05:37:03 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-01-29 05:37:55 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-01-29 05:38:50 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-01-29 05:43:07 --> 404 Page Not Found: 
ERROR - 2022-01-29 05:43:35 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-01-29 05:46:20 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-01-29 05:47:19 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-01-29 05:47:25 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-01-29 05:47:43 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 47
ERROR - 2022-01-29 05:47:59 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-01-29 05:52:30 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 77
ERROR - 2022-01-29 05:52:34 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 77
ERROR - 2022-01-29 05:53:21 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 77
ERROR - 2022-01-29 05:53:24 --> Severity: Notice --> Undefined index: name D:\xampp\htdocs\ShivaEducation\application\modules\admin\controllers\ecommerce\ShopCategories.php 77
