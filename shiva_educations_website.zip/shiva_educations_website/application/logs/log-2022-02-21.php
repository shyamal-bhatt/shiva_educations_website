<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-21 10:43:42 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-21 10:44:08 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-21 10:48:38 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-21 12:05:25 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-21 12:21:07 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-21 12:26:09 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-02-21 12:36:08 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:36:08 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:36:08 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:36:19 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:36:19 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:36:19 --> 404 Page Not Found: /index
