<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-19 05:05:30 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-19 05:06:55 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-19 05:08:38 --> 404 Page Not Found: 
ERROR - 2022-03-19 05:09:32 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-19 05:09:35 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-19 19:07:04 --> Severity: Notice --> Trying to access array offset on value of type null D:\xampp\htdocs\ShivaEducation\application\views\templates\redlabel\checkout.php 53
ERROR - 2022-03-19 19:08:52 --> 404 Page Not Found: 
