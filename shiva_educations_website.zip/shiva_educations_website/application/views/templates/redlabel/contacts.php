<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<style>
    #map {
        height: 400px;
        width: 100%;
    }
</style>
<div id="contacts">
    <div class="jumbotron jumbotron-sm">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-lg-12">
                    <h1 class="h1">
                        <?= lang('feedback') //lang('contact_us') 
                        ?> <small><?= lang('feel_free_feedback') //lang('contact_us_feel_free') 
                                    ?></small></h1>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <?php
                if ($this->session->flashdata('resultSend')) {
                ?>
                    <hr>
                    <div class="alert alert-info"><?= $this->session->flashdata('resultSend') ?></div>
                    <hr>
                <?php }
                ?>
                <div class="well well-sm">

                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">
                                        <?= lang('name') ?></label>
                                    <input type="text" name="name" class="form-control" id="name" placeholder="Enter name" required="required" />
                                </div>
                                <div class="form-group">
                                    <label for="email">
                                        <?= lang('email_address') ?></label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span>
                                        </span>
                                        <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" required="required" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="subject">
                                        <?= lang('subject') ?></label>
                                    <input type="text" name="subject" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">
                                        <?= lang('message') ?></label>
                                    <textarea name="message" id="message" class="form-control" rows="9" cols="25" required="required" placeholder="<?= lang('message') ?>"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" id="btnContactUs">
                                    <?= lang('send_message') ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <form>
                    <legend><span class="glyphicon glyphicon-globe"></span> <?= lang('our_office') ?></legend>
                    <address>
                        <?= html_entity_decode($contactspage) ?>
                    </address>
                </form>
            </div>
        </div>
    </div>

    <!-- Google Map iframe -->
    <button type="button" class="btn btn-outline-warning" style="font-family:Roboto,Arial,sans-serif; font-size: 24px; width: 100%; text-align: center ; margin-top:5rem">Here we are!</button>
    <div style="height: 100%; width: 100%;display: table; position: relative;">

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3692.268630730039!2d73.18421841487655!3d22.26781178534047!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x6f1642cd4677e961!2zMjLCsDE2JzA0LjEiTiA3M8KwMTEnMTEuMSJF!5e0!3m2!1sen!2sin!4v1643363206167!5m2!1sen!2sin" width="100%" height="400" allowfullscreen="" loading="lazy"></iframe>
</div>


<br><br>

<!-- MAP Section under Contact Us page  -->
<!-- <?php if (trim($googleApi) != null && trim($googleMaps) != null) { ?>
    <div id="map">
    </div>
    <?php $coordinates = explode(',', $googleMaps); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?= $googleApi ?>"></script>
    <script>
        function initialize() {
            var myLatlng = new google.maps.LatLng(<?= $coordinates[0] ?>, <?= $coordinates[1] ?>);
            var mapOptions = {
                zoom: 10,
                center: myLatlng
            }
            var map = new google.maps.Map(document.getElementById("map"), mapOptions);
            var marker = new google.maps.Marker({
                position: myLatlng,
                title: "Here we are!"
            });
            marker.setMap(map);
        }
        google.maps.event.addDomListener(window, 'load', initialize);
    </script>
    <?php } ?> -->
</div>